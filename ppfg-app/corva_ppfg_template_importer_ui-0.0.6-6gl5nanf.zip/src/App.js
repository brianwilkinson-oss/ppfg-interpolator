import { useRef, useEffect } from 'react';
import { AppHeader } from '@corva/ui/components';
import htmlContent from './ppfgHtml';

function App(props) {
  const { appHeaderProps } = props;
  const iframeRef = useRef(null);

  useEffect(() => {
    if (iframeRef.current) {
      const doc = iframeRef.current.contentDocument;
      doc.open();
      doc.write(htmlContent);
      doc.close();
    }
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <AppHeader {...appHeaderProps} />
      <iframe
        ref={iframeRef}
        title="PPFG Interpolator"
        style={{
          flex: 1,
          width: '100%',
          border: 'none',
          background: '#14161e',
        }}
        sandbox="allow-scripts allow-same-origin allow-downloads"
      />
    </div>
  );
}

export default App;
